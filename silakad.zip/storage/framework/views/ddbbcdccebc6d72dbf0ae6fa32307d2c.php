<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-sm-12">
                    <h3 class="mb-0">Riwayat</h3>
                    <div class="container mt-3">
                        <?php if(session('success')): ?>
                            <div class="alert alert-success">
                                <?php echo e(session('success')); ?>

                            </div>
                        <?php endif; ?>

                        <?php if(session('error')): ?>
                            <div class="alert alert-danger">
                                <?php echo e(session('error')); ?>

                            </div>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="card">
                    <div class="card-body">
                        <table id="user-admin" class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>NO</th>
                                    <th>Nama Lengkap Mhs</th>
                                    <th>Jenis Layanan</th>
                                    <th>Status</th>
                                    <th>Lapor</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $data_lomba; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($data->user->nama_lengkap); ?></td>
                                        <td><?php echo e($data->jenis_layanan); ?></td>
                                        <td><?php echo e($data->status); ?></td>
                                        <td>
                                            <a class="btn btn-outline-danger"
                                                href="<?php echo e(route('detaillomba', ['id' => $data->id])); ?>">Detail</a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('tendik.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Project\JURUSAN\silakad\resources\views\tendik\verifikasi\rekomendasi\lomba.blade.php ENDPATH**/ ?>