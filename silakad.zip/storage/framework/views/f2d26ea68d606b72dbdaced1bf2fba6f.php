<footer class="footer">
    <div class="d-sm-flex justify-content-center justify-content-sm-between">
        <span class="text-muted text-center text-sm-left d-block d-sm-inline-block">SILAKAD - <a
                href="https://itk.ac.id/jmti-itk/" target="_blank">Jurusan Matematika dan Teknologi
                Informasi</a></span>
        <span class="float-none float-sm-end d-block mt-1 mt-sm-0 text-center">Copyright © 2024. All rights
            reserved.</span>
    </div>
</footer>
<?php /**PATH E:\Project\JURUSAN\silakad\resources\views\tendik\layouts\partials\footer.blade.php ENDPATH**/ ?>