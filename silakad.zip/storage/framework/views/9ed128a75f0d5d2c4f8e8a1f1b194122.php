<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <div class="row">
            <div class="col-sm-12">
                <div class="home-tab">
                    <div class="tab-content tab-content-basic">
                        <div class="tab-pane fade show active" id="overview" role="tabpanel" aria-labelledby="overview">
                            <div class="container mt-3">
                                <?php if(session('success')): ?>
                                    <script>
                                        Swal.fire({
                                            icon: 'success',
                                            title: 'Berhasil',
                                            text: '<?php echo e(session('success')); ?>',
                                        });
                                    </script>
                                <?php endif; ?>
                                <?php if(session('error')): ?>
                                    <script>
                                        Swal.fire({
                                            icon: 'error',
                                            title: 'Gagal',
                                            text: '<?php echo e(session('error')); ?>',
                                        });
                                    </script>
                                <?php endif; ?>
                            </div>
                            <div class="row">
                                <div class="col-12 col-sm-6 col-md-3">
                                    <div class="info-box"> <span class="info-box-icon text-bg-primary shadow-sm"> <i
                                                class="bi bi-hourglass-split"></i> </span>
                                        <div class="info-box-content"> <span class="info-box-text">Pending</span> <span
                                                class="info-box-number">
                                                <?php echo e($total_pending); ?></span>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-12 col-sm-6 col-md-3">
                                    <div class="info-box"> <span class="info-box-icon text-bg-warning shadow-sm">
                                            <i class="bi bi-arrow-repeat"></i>
                                        </span>
                                        <div class="info-box-content">
                                            <span class="info-box-text">Verifikasi</span>
                                            <span class="info-box-number">
                                                <?php echo e($total_diproses); ?></span>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-12 col-sm-6 col-md-3">
                                    <div class="info-box"> <span class="info-box-icon text-bg-success shadow-sm"> <i
                                                class="bi bi-check-all"></i> </span>
                                        <div class="info-box-content"> <span class="info-box-text">Terima</span> <span
                                                class="info-box-number">
                                                <?php echo e($total_diterima); ?></span>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-12 col-sm-6 col-md-3">
                                    <div class="info-box"> <span class="info-box-icon text-bg-danger shadow-sm">
                                            <i class="bi bi-x-lg"></i> </span>
                                        <div class="info-box-content"> <span class="info-box-text">Tolak</span> <span
                                                class="info-box-number">
                                                <?php echo e($total_ditolak); ?></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-lg-12 d-flex flex-column">
                                    <div class="row flex-grow">
                                        <div class="col-12 col-lg-4 col-lg-12 grid-margin stretch-card">
                                            <div class="card card-rounded">
                                                <div class="card-body">
                                                    <h4 class="card-title card-title-dash">Riwayat</h4>
                                                    <table id="user-mhs" class="table table-striped">
                                                        <thead>
                                                            <tr>
                                                                <th class="text-center">NO</th>
                                                                <th>Jenis Layanan</th>
                                                                <th class="text-center">Status</th>
                                                                
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            <?php $__currentLoopData = $all_riwayat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $riwayat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <tr>
                                                                    <td class="text-center"><?php echo e($loop->iteration); ?></td>
                                                                    <td><?php echo e($riwayat->jenis_layanan ?? 'N/A'); ?></td>
                                                                    <td class="text-center">
                                                                        <?php if($riwayat->status == 'pending'): ?>
                                                                            <span
                                                                                class="badge badge-secondary">Pending</span>
                                                                        <?php elseif($riwayat->status == 'diterima'): ?>
                                                                            <span
                                                                                class="badge badge-success">Diterima</span>
                                                                        <?php elseif($riwayat->status == 'ditolak'): ?>
                                                                            <span class="badge badge-danger">Ditolak</span>
                                                                        <?php elseif($riwayat->status == 'selesai'): ?>
                                                                            <span class="badge badge-primary">Selesai</span>
                                                                        <?php else: ?>
                                                                            <span class="badge badge-secondary">N/A</span>
                                                                        <?php endif; ?>
                                                                    </td>
                                                                    
                                                                </tr>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('mahasiswa.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Project\JURUSAN\silakad\resources\views\mahasiswa\dashboard.blade.php ENDPATH**/ ?>