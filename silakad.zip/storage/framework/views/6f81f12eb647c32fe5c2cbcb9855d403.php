<?php $__env->startSection('content'); ?>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/5.0.0-beta3/css/bootstrap.min.css" rel="stylesheet">

    <div class="content-wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-sm-12">
                    <h3 class="mb-0">Riwayat</h3>
                    <div class="container mt-3">
                        <?php if(session('success')): ?>
                            <div class="alert alert-success">
                                <?php echo e(session('success')); ?>

                            </div>
                        <?php endif; ?>

                        <?php if(session('error')): ?>
                            <div class="alert alert-danger">
                                <?php echo e(session('error')); ?>

                            </div>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="card">
                    <div class="card-body">
                        <table id="user-admin" class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th class="small-width text-center">NO</th>
                                    <th class="text-center">Nama mahasiswa</th>
                                    <th class="text-center">Jenis Layanan</th>
                                    <th class="text-center">Status</th>
                                    <th class="text-center">Lapor</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $dataTA; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="text-center"><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($data->user->nama_lengkap); ?></td>
                                        <td><?php echo e($data->jenis_layanan); ?></td>
                                        <td class="text-center">
                                            <?php if($data->status == 'pending'): ?>
                                                <span class="badge rounded-pill text-bg-primary">Pending</span>
                                            <?php elseif($data->status == 'diproses'): ?>
                                                <span class="badge rounded-pill text-bg-warning text-dark">Proses</span>
                                            <?php elseif($data->status == 'diterima'): ?>
                                                <span class="badge rounded-pill text-bg-success">Terima</span>
                                            <?php elseif($data->status == 'ditolak'): ?>
                                                <span class="badge rounded-pill text-bg-danger">Tolak</span>
                                            <?php elseif($data->status == 'selesai'): ?>
                                                <span class="badge rounded-pill text-bg-dark">Selesai</span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="text-center">
                                            <a class="btn btn-outline-danger"
                                                href="<?php echo e(route('detaildataTA', ['id' => $data->id])); ?>">Detail</a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('tendik.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Project\JURUSAN\silakad\resources\views\tendik\verifikasi\permohonan\data_tugas_akhir.blade.php ENDPATH**/ ?>