<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <div class="row">
            <div class="col-sm-12">
                <div class="home-tab">
                    <div class="tab-content tab-content-basic">
                        <div class="tab-pane fade show active" id="overview" role="tabpanel" aria-labelledby="overview">
                            <div class="row">
                                <div class="col-12 col-sm-6 col-md-3">
                                    <div class="info-box"> <span class="info-box-icon text-bg-primary shadow-sm"> <i
                                                class="bi bi-person"></i> </span>
                                        <div class="info-box-content"> <span class="info-box-text">Mahasiswa</span> <span
                                                class="info-box-number">
                                                <?php echo e($mahasiswa); ?></span>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-12 col-sm-6 col-md-3">
                                    <div class="info-box"> <span class="info-box-icon text-bg-green shadow-sm"> <i
                                                class="bi bi-person-gear"></i> </span>
                                        <div class="info-box-content"> <span class="info-box-text">Tendik</span> <span
                                                class="info-box-number">
                                                <?php echo e($tendik); ?></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Project\JURUSAN\silakad\resources\views\admin\dashboard.blade.php ENDPATH**/ ?>